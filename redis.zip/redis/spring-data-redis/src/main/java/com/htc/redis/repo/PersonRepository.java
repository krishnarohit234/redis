package com.htc.redis.repo;

import java.util.Map;

import com.htc.redis.model.Person;


public interface PersonRepository {

	public void savePerson(Person p);
	public void deletePerson(Integer id);
	public void updatePerson(Person p);
	
	public Person getOnePerson(Integer id);
	public Map<Integer,Person> getAllPerson();
}