package com.htc.redis.repo.impl;

import java.util.Map;
import javax.annotation.Resource;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.stereotype.Repository;

import com.htc.redis.model.Person;
import com.htc.redis.repo.PersonRepository;



@Repository
public class PersonRepositoryImpl implements PersonRepository {
	
	private final String KEY="PERSON"; //MAP NAME

	// MAP NAME TYPE,  MAP KEY TYPE, MAP VALUE TYPE
	@Resource(name = "rtPer") 
	private HashOperations<String, Integer, Person> opr;
	
	@Override
	public void savePerson(Person p) {
		opr.putIfAbsent(KEY, p.getPid(), p);
	}

	@Override
	public void deletePerson(Integer id) {
		opr.delete(KEY, id);
	}

	@Override
	public void updatePerson(Person p) {
		opr.put(KEY, p.getPid(),p);
	}

	@Override
	public Person getOnePerson(Integer id) {
		Person p=opr.get(KEY, id);
		return p;
	}

	@Override
	public Map<Integer, Person> getAllPerson() {
		Map<Integer, Person> map=opr.entries(KEY);
		return map;
	}

}