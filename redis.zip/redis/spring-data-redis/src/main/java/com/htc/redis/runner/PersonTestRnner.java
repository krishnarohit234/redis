package com.htc.redis.runner;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.htc.redis.model.Person;
import com.htc.redis.repo.PersonRepository;



@Component
public class PersonTestRnner implements CommandLineRunner{
	@Autowired
	private PersonRepository repo;
	
	@Override
	public void run(String... args) throws Exception {
		repo.savePerson(new Person(10, "A", 25, "AA-856"));
		repo.savePerson(new Person(11, "B", 45, "NA-899"));
		repo.savePerson(new Person(12, "C", 82, "AM-452"));
		repo.savePerson(new Person(13, "D", 16, "XY-652"));
		
		repo.getAllPerson().forEach((k,v)->System.out.println(k+"-"+v));
		
		repo.deletePerson(13);
		repo.updatePerson(new Person(12, "C-NEW", 83, "AM-452-NEW"));
		
		repo.getAllPerson().forEach((k,v)->System.out.println(k+"-"+v));
		System.out.println(repo.getOnePerson(10));
	}
}