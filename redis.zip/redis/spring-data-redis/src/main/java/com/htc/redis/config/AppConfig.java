package com.htc.redis.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.htc.redis.model.Person;

@Configuration
public class AppConfig {

	@Bean
	public LettuceConnectionFactory conn() {
		LettuceConnectionFactory con=new LettuceConnectionFactory();
		return con;
	}
	@Bean
	public RedisTemplate<Integer, Person> rtPer(){
		RedisTemplate<Integer, Person> rt=new RedisTemplate<>();
		rt.setConnectionFactory(conn());
		return rt;
	}
}