package com.htc.redis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataRedisApplicationTests {

	@Test
	void contextLoads() {
	}

}
