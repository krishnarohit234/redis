package com.htc.redis.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.htc.redis.ResourceNotException;
import com.htc.redis.model.Employee;
import com.htc.redis.repo.EmployeeRepository;
import com.htc.redis.service.IEmployeeService;

@Service
public class EmployeeServiceImpl implements IEmployeeService{

	@Autowired
	private EmployeeRepository repo;
	
	
	@Override
	public Employee saveEmployee(Employee e) {
		
		return repo.save(e);
	}

	@Override
	@CachePut(value ="employees",key="#empId")
	public Employee updateEmployee(Integer empId, Employee e) {
		Employee emp=repo.findById(empId).orElseThrow(()->new ResourceNotException("Employe not exist") );
		emp.setEmpName(e.getEmpName());
		emp.setEmpsal(e.getEmpsal());
		return repo.save(e);
	}

	@Override
	@CacheEvict(value ="employees",key="#empId")
	public void deleteEmployee(Integer empId) {
		Employee emp=repo.findById(empId).orElseThrow(()->new ResourceNotException("Employe not exist") );
		repo.delete(emp);
	}

	@Override
	@Cacheable(value ="employees",key="#empId")
	public Employee getOneEmployees(Integer empId) {
		Employee emp=repo.findById(empId).orElseThrow(()->new ResourceNotException("Employe not exist") );
		return emp;
	}

	@Override
	public List<Employee> getAllEmployes() {
		
		return repo.findAll();
	}

}

/*http://localhost:8085/employee/save
http://localhost:8085/employee/all
http://localhost:8085/employee/one/1
http://localhost:8085/employee/remove/4
http://localhost:8085/employee/modify/4*/