package com.htc.redis.service;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.htc.redis.model.Employee;

public interface IEmployeeService {

	public Employee saveEmployee(Employee e);
	public Employee updateEmployee(Integer empId,Employee e);
	public void deleteEmployee(Integer empId);
	
	public Employee getOneEmployees(Integer empId);
	public List<Employee> getAllEmployes();
	
}
